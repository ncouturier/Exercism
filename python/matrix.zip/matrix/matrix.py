class Matrix:
    def __init__(self, matrix_string):
        pass

    def row(self, index):
        pass

    def column(self, index):
        pass
